/*

JANGAN DI PERJUAL BELIKAN

THX TO JGN DIHAPUS

THX TO DI HAPUS?? 

GW BERHANTI UPDATE

CAPEK" BIKIN SC MALAH DIHAPUS

DAHLAH

*/
exports.menuZ = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => {
	return`╭════❲ *WHATSAPP* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : NAYLA*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}ownermenu*
┃✜╿${tz} *${prefix}grupmenu*
┃✜╿${tz} *${prefix}makermenu*
┃✜╿${tz} *${prefix}nsfwmenu*
┃✜╿${tz} *${prefix}animemenu*
┃✜╿${tz} *${prefix}promenu*
┃✜╿${tz} *${prefix}downloadmenu*
┃✜╿${tz} *${prefix}soundmenu*
┃✜╿${tz} *${prefix}pornmenu*
┃✜╿${tz} *${prefix}internalmenu*
┃✜╿${tz} *${prefix}cekmenu*
┃✜╿${tz} *${prefix}tagmenu*
┃✜╿${tz} *${prefix}gamemenu*
┃✜╿${tz} *${prefix}randomtext*
┃✜╿${tz} *${prefix}fastmenu*
┃✜╿${tz} *${prefix}sertifikat*
┃✜╿${tz} *${prefix}makerfoto*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.botx = (prefix) => {
	return`[❗] MODE BOTX TIDAK AKTIF\nKETIK *${prefix}botx*\nUNTUK MENGAKTIFKAN`
	}
exports.error = (prefix, command) => {
    return`[❗] ERROR SILAHKAN LAPORKAN KE OWNER. KETIK *${prefix}bug ${command}*\n[ *APIKEY UNFALID* ]`
    }
exports.info1 = () => { 
    return`🐳 = $200
🦈 = $121
🐬 = $104
🐋 = $94
🐟 = $87
🐠 = $79
🦐 = $62
🦑 = $34
🦀 = $17
🐚 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
  }
exports.info2 = () => { 
    return`🐔 = $200
🦃 = $121
🐿 = $104
🐐 = $94
🐏 = $87
🐖 = $79
🐑 = $62
🐎 = $34
🐺 = $17
🦩 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
}
exports.info3 = () => { 
    return`🦋 = $200
🕷 = $121
🐝 = $104
🐉 = $94
🦆 = $87
🦅 = $79
🕊 = $62
🐧 = $34
🐦 = $17
🦇 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
} 
exports.grupmenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *GRUPMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}hidetag*
┃✜╿${tz} *${prefix}add*
┃✜╿${tz} *${prefix}kick*
┃✜╿${tz} *${prefix}promote*
┃✜╿${tz} *${prefix}demote*
┃✜╿${tz} *${prefix}antilink*
┃✜╿${tz} *${prefix}hidetag10*
┃✜╿${tz} *${prefix}group*
┃✜╿${tz} *${prefix}antigay*
┃✜╿${tz} *${prefix}antibocil*
┃✜╿${tz} *${prefix}antiwibu*
┃✜╿${tz} *${prefix}antijawa*
┃✜╿${tz} *${prefix}setout*
┃✜╿${tz} *${prefix}setwelcome*
┃✜╿${tz} *${prefix}setthumb*
┃✜╿${tz} *${prefix}katajago*
┃✜╿${tz} *${prefix}linkgc*
┃✜╿${tz} *${prefix}tagall*
┃✜╿${tz} *${prefix}delete*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.makermenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *MAKERMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}maker1*                   
┃✜╿${tz} *${prefix}maker2*                   
┃✜╿${tz} *${prefix}maker3*                   
┃✜╿${tz} *${prefix}maker4*                   
┃✜╿${tz} *${prefix}maker5*                   
┃✜╿${tz} *${prefix}maker6*                   
┃✜╿${tz} *${prefix}maker7*                   
┃✜╿${tz} *${prefix}maker8*                   
┃✜╿${tz} *${prefix}maker9*                   
┃✜╿${tz} *${prefix}maker10*                   
┃✜╿${tz} *${prefix}maker11*                   
┃✜╿${tz} *${prefix}maker12*                   
┃✜╿${tz} *${prefix}maker13*                   
┃✜╿${tz} *${prefix}maker14*                   
┃✜╿${tz} *${prefix}maker15*                   
┃✜╿${tz} *${prefix}maker16*                   
┃✜╿${tz} *${prefix}maker17*                   
┃✜╿${tz} *${prefix}maker18*   
┃✜╿${tz} *${prefix}maker19*                   
┃✜╿${tz} *${prefix}maker20*         
┃✜╿${tz} *${prefix}maker21*                   
┃✜╿${tz} *${prefix}maker22*                   
┃✜╿${tz} *${prefix}maker23*                   
┃✜╿${tz} *${prefix}maker24*                   
┃✜╿${tz} *${prefix}maker25*                   
┃✜╿${tz} *${prefix}maker26*                   
┃✜╿${tz} *${prefix}maker27*                   
┃✜╿${tz} *${prefix}maker28*                   
┃✜╿${tz} *${prefix}maker29*                   
┃✜╿${tz} *${prefix}maker30*         
┃✜╿${tz} *${prefix}maker31*                   
┃✜╿${tz} *${prefix}maker32*                   
┃✜╿${tz} *${prefix}maker33*                   
┃✜╿${tz} *${prefix}maker34*                   
┃✜╿${tz} *${prefix}maker35*                   
┃✜╿${tz} *${prefix}maker36*                   
┃✜╿${tz} *${prefix}maker37*                   
┃✜╿${tz} *${prefix}maker38*                   
┃✜╿${tz} *${prefix}maker39*                   
┃✜╿${tz} *${prefix}maker40*         
┃✜╿${tz} *${prefix}maker41*                   
┃✜╿${tz} *${prefix}maker42*                   
┃✜╿${tz} *${prefix}maker43*                   
┃✜╿${tz} *${prefix}maker44*                   
┃✜╿${tz} *${prefix}maker45*                   
┃✜╿${tz} *${prefix}maker46*                   
┃✜╿${tz} *${prefix}maker47*                   
┃✜╿${tz} *${prefix}maker48*                   
┃✜╿${tz} *${prefix}maker49*                   
┃✜╿${tz} *${prefix}maker50*         
┃✜╿${tz} *${prefix}maker51*                   
┃✜╿${tz} *${prefix}maker52*                   
┃✜╿${tz} *${prefix}maker53*                   
┃✜╿${tz} *${prefix}maker54*                   
┃✜╿${tz} *${prefix}maker55*                                     
┃✜╿${tz} *${prefix}maker57*                   
┃✜╿${tz} *${prefix}maker58*                   
┃✜╿${tz} *${prefix}maker59*                   
┃✜╿${tz} *${prefix}maker60*         
┃✜╿${tz} *${prefix}maker61*                   
┃✜╿${tz} *${prefix}maker62*                   
┃✜╿${tz} *${prefix}maker63*                   
┃✜╿${tz} *${prefix}maker64*                   
┃✜╿${tz} *${prefix}maker65*                   
┃✜╿${tz} *${prefix}maker66*                   
┃✜╿${tz} *${prefix}maker67*                   
┃✜╿${tz} *${prefix}maker68*                   
┃✜╿${tz} *${prefix}maker69*                   
┃✜╿${tz} *${prefix}maker70*         
┃✜╿${tz} *${prefix}maker71*                   
┃✜╿${tz} *${prefix}maker72*       
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.nsfwmenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *NSFWMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}nhentai*
┃✜╿${tz} *${prefix}art*
┃✜╿${tz} *${prefix}bts*
┃✜╿${tz} *${prefix}exo*
┃✜╿${tz} *${prefix}elf*
┃✜╿${tz} *${prefix}loli*
┃✜╿${tz} *${prefix}neko*
┃✜╿${tz} *${prefix}waifu*
┃✜╿${tz} *${prefix}shota*
┃✜╿${tz} *${prefix}husbu*
┃✜╿${tz} *${prefix}sagiri*
┃✜╿${tz} *${prefix}shinobu*
┃✜╿${tz} *${prefix}megumin*
┃✜╿${tz} *${prefix}wallnime*                                   
┃✜╿${tz} *${prefix}bj*
┃✜╿${tz} *${prefix}ero*
┃✜╿${tz} *${prefix}cum*
┃✜╿${tz} *${prefix}feet*
┃✜╿${tz} *${prefix}yuri*
┃✜╿${tz} *${prefix}trap*
┃✜╿${tz} *${prefix}lewd*
┃✜╿${tz} *${prefix}feed*
┃✜╿${tz} *${prefix}eron*
┃✜╿${tz} *${prefix}solo*
┃✜╿${tz} *${prefix}gasm*
┃✜╿${tz} *${prefix}poke*
┃✜╿${tz} *${prefix}anal*
┃✜╿${tz} *${prefix}holo*
┃✜╿${tz} *${prefix}tits*
┃✜╿${tz} *${prefix}kuni*
┃✜╿${tz} *${prefix}kiss*
┃✜╿${tz} *${prefix}erok*
┃✜╿${tz} *${prefix}smug*
┃✜╿${tz} *${prefix}baka*
┃✜╿${tz} *${prefix}solog*
┃✜╿${tz} *${prefix}feetg*
┃✜╿${tz} *${prefix}lewdk*
┃✜╿${tz} *${prefix}waifu*
┃✜╿${tz} *${prefix}pussy*
┃✜╿${tz} *${prefix}femdom*
┃✜╿${tz} *${prefix}cuddle*
┃✜╿${tz} *${prefix}hentai*
┃✜╿${tz} *${prefix}eroyuri*
┃✜╿${tz} *${prefix}cum_jpg*
┃✜╿${tz} *${prefix}blowjob*
┃✜╿${tz} *${prefix}erofeet*
┃✜╿${tz} *${prefix}holoero*
┃✜╿${tz} *${prefix}classic*
┃✜╿${tz} *${prefix}erokemo*
┃✜╿${tz} *${prefix}fox_girl*
┃✜╿${tz} *${prefix}futanari*
┃✜╿${tz} *${prefix}lewdkemo*
┃✜╿${tz} *${prefix}wallpaper*
┃✜╿${tz} *${prefix}pussy_jpg*
┃✜╿${tz} *${prefix}kemonomimi*
┃✜╿${tz} *${prefix}nsfw_avatar* 
┃✜╿${tz} *${prefix}orgy*                     
┃✜╿${tz} *${prefix}nsfwneko*
┃✜╿${tz} *${prefix}mstrb* 
┃✜╿${tz} *${prefix}manga* 
┃✜╿${tz} *${prefix}jahy* 
┃✜╿${tz} *${prefix}hentaigif* 
┃✜╿${tz} *${prefix}hentai* 
┃✜╿${tz} *${prefix}glasses*
┃✜╿${tz} *${prefix}gangbang* 
┃✜╿${tz} *${prefix}ero* 
┃✜╿${tz} *${prefix}cuckold* 
┃✜╿${tz} *${prefix}blowjob* 
┃✜╿${tz} *${prefix}bdsm* 
┃✜╿${tz} *${prefix}ass* 
┃✜╿${tz} *${prefix}ahegao* 
┃✜╿${tz} *${prefix}zettairyouiki* 
┃✜╿${tz} *${prefix}wpnsfwmobile* 
┃✜╿${tz} *${prefix}wpmobile* 
┃✜╿${tz} *${prefix}wallpaper*
┃✜╿${tz} *${prefix}thighs* 
┃✜╿${tz} *${prefix}uniform*
┃✜╿${tz} *${prefix}tentacles* 
┃✜╿${tz} *${prefix}sfwneko* 
┃✜╿${tz} *${prefix}pussy* 
┃✜╿${tz} *${prefix}panties* 
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.animemenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *ANIMEMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}naruto* 
┃✜╿${tz} *${prefix}mikasa* 
┃✜╿${tz} *${prefix}eren*  
┃✜╿${tz} *${prefix}titan*  
┃✜╿${tz} *${prefix}levi*  
┃✜╿${tz} *${prefix}sakura*  
┃✜╿${tz} *${prefix}hinata*  
┃✜╿${tz} *${prefix}neji*  
┃✜╿${tz} *${prefix}minato*  
┃✜╿${tz} *${prefix}jiraya*  
┃✜╿${tz} *${prefix}tsunade*  
┃✜╿${tz} *${prefix}kiba*  
┃✜╿${tz} *${prefix}boruto*  
┃✜╿${tz} *${prefix}sarada*  
┃✜╿${tz} *${prefix}sasuke*  
┃✜╿${tz} *${prefix}madara*  
┃✜╿${tz} *${prefix}obito*  
┃✜╿${tz} *${prefix}obito*  
┃✜╿${tz} *${prefix}tanjiro*  
┃✜╿${tz} *${prefix}nezuko*  
┃✜╿${tz} *${prefix}luffy*  
┃✜╿${tz} *${prefix}zoro*  
┃✜╿${tz} *${prefix}sanji* 
┃✜╿${tz} *${prefix}gon*  
┃✜╿${tz} *${prefix}killua*  
┃✜╿${tz} *${prefix}sagiri*  
┃✜╿${tz} *${prefix}rimuru*  
┃✜╿${tz} *${prefix}natsu*  
┃✜╿${tz} *${prefix}genos*  
┃✜╿${tz} *${prefix}saitama*  
┃✜╿${tz} *${prefix}miku* 
┃✜╿${tz} *${prefix}neko*
┃✜╿${tz} *${prefix}twich*
┃✜╿${tz} *${prefix}loli*                  
┃✜╿${tz} *${prefix}anime*
┃✜╿${tz} *${prefix}anime1*                                    
┃✜╿${tz} *${prefix}yuri*
┃✜╿${tz} *${prefix}tongue*
┃✜╿${tz} *${prefix}neko1*                                                                        
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.promenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *PROMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}phkomen*
┃✜╿${tz} *${prefix}semoji*
┃✜╿${tz} *${prefix}wallteknologi*
┃✜╿${tz} *${prefix}wallhacker*
┃✜╿${tz} *${prefix}wallcyber*
┃✜╿${tz} *${prefix}wallmuslim*
┃✜╿${tz} *${prefix}wallpegunungan*
┃✜╿${tz} *${prefix}caklontong*
┃✜╿${tz} *${prefix}robot*
┃✜╿${tz} *${prefix}3dwhite*
┃✜╿${tz} *${prefix}daun*
┃✜╿${tz} *${prefix}metal1*
┃✜╿${tz} *${prefix}metal*
┃✜╿${tz} *${prefix}scary*
┃✜╿${tz} *${prefix}imo*
┃✜╿${tz} *${prefix}wallpaper*
┃✜╿${tz} *${prefix}tahta*
┃✜╿${tz} *${prefix}neon2*
┃✜╿${tz} *${prefix}wall*
┃✜╿${tz} *${prefix}wolf*
┃✜╿${tz} *${prefix}tfire*
┃✜╿${tz} *${prefix}ytgold*
┃✜╿${tz} *${prefix}ytsilver*
┃✜╿${tz} *${prefix}t3d*
┃✜╿${tz} *${prefix}logoa*
┃✜╿${tz} *${prefix}pornhub*
┃✜╿${tz} *${prefix}marvel*
┃✜╿${tz} *${prefix}leavest*
┃✜╿${tz} *${prefix}phcoment*
┃✜╿${tz} *${prefix}nulis*
┃✜╿${tz} *${prefix}neon1*
┃✜╿${tz} *${prefix}text3d*
┃✜╿${tz} *${prefix}galaxy*
┃✜╿${tz} *${prefix}gaming*
┃✜╿${tz} *${prefix}colors*
┃✜╿${tz} *${prefix}kling*
┃✜╿${tz} *${prefix}barcode*
┃✜╿${tz} *${prefix}qrcode*
┃✜╿${tz} *${prefix}8bit*
┃✜╿${tz} *${prefix}burn*
┃✜╿${tz} *${prefix}fire*
┃✜╿${tz} *${prefix}google*
┃✜╿${tz} *${prefix}battle*
┃✜╿${tz} *${prefix}block*
┃✜╿${tz} *${prefix}candy*
┃✜╿${tz} *${prefix}potter*
┃✜╿${tz} *${prefix}silk*
┃✜╿${tz} *${prefix}water*
┃✜╿${tz} *${prefix}pubg*
┃✜╿${tz} *${prefix}neon*
┃✜╿${tz} *${prefix}coffe1*
┃✜╿${tz} *${prefix}coffe*
┃✜╿${tz} *${prefix}tiktok*
┃✜╿${tz} *${prefix}shadow*
┃✜╿${tz} *${prefix}romance*
┃✜╿${tz} *${prefix}glass*
┃✜╿${tz} *${prefix}naruto*
┃✜╿${tz} *${prefix}mug1*
┃✜╿${tz} *${prefix}love*
┃✜╿${tz} *${prefix}mug*
┃✜╿${tz} *${prefix}neon1*
┃✜╿${tz} *${prefix}smoke*
┃✜╿${tz} *${prefix}rainbow*
┃✜╿${tz} *${prefix}nulis1*
┃✜╿${tz} *${prefix}nulis2*
┃✜╿${tz} *${prefix}nulis3*
┃✜╿${tz} *${prefix}nulis4*
┃✜╿${tz} *${prefix}nulis5*
┃✜╿${tz} *${prefix}nulis6*
┃✜╿${tz} *${prefix}video1*
┃✜╿${tz} *${prefix}video2*
┃✜╿${tz} *${prefix}video3*
┃✜╿${tz} *${prefix}video4*
┃✜╿${tz} *${prefix}video5*
┃✜╿${tz} *${prefix}video6*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.downloadmenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭══❲ *DOWNLOADMENU* ❳══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}telesticker*
┃✜╿${tz} *${prefix}tiktokmusic*
┃✜╿${tz} *${prefix}tiktoknowm*
┃✜╿${tz} *${prefix}igfoto*
┃✜╿${tz} *${prefix}igvideo*
┃✜╿${tz} *${prefix}ytsearch*
┃✜╿${tz} *${prefix}ytmp3*
┃✜╿${tz} *${prefix}ytmp4*
┃✜╿${tz} *${prefix}play*
┃✜╿${tz} *${prefix}brainly*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.soundmenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *SOUNDMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}sound1*
┃✜╿${tz} *${prefix}sound2*
┃✜╿${tz} *${prefix}sound3*
┃✜╿${tz} *${prefix}sound4*
┃✜╿${tz} *${prefix}sound5*
┃✜╿${tz} *${prefix}sound6*
┃✜╿${tz} *${prefix}sound7*
┃✜╿${tz} *${prefix}sound8*
┃✜╿${tz} *${prefix}sound9*
┃✜╿${tz} *${prefix}sound10*
┃✜╿${tz} *${prefix}sound11*
┃✜╿${tz} *${prefix}sound12*
┃✜╿${tz} *${prefix}sound13*
┃✜╿${tz} *${prefix}sound14*
┃✜╿${tz} *${prefix}sound15*
┃✜╿${tz} *${prefix}sound16*
┃✜╿${tz} *${prefix}sound17*
┃✜╿${tz} *${prefix}sound18*
┃✜╿${tz} *${prefix}sound19*
┃✜╿${tz} *${prefix}sound20*
┃✜╿${tz} *${prefix}sound21*
┃✜╿${tz} *${prefix}sound22*
┃✜╿${tz} *${prefix}sound23*
┃✜╿${tz} *${prefix}sound24*
┃✜╿${tz} *${prefix}sound25*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.pornmenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *PORNMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}indo1* 
┃✜╿${tz} *${prefix}indo2* 
┃✜╿${tz} *${prefix}indo3* 
┃✜╿${tz} *${prefix}indo4* 
┃✜╿${tz} *${prefix}indo5* 
┃✜╿${tz} *${prefix}indo6* 
┃✜╿${tz} *${prefix}indo7* 
┃✜╿${tz} *${prefix}indo8* 
┃✜╿${tz} *${prefix}indo9* 
┃✜╿${tz} *${prefix}indo10* 
┃✜╿${tz} *${prefix}indo11* 
┃✜╿${tz} *${prefix}indo12* 
┃✜╿${tz} *${prefix}indo13* 
┃✜╿${tz} *${prefix}indo14* 
┃✜╿${tz} *${prefix}indo15* 
┃✜╿${tz} *${prefix}indo16* 
┃✜╿${tz} *${prefix}indo17* 
┃✜╿${tz} *${prefix}indo18* 
┃✜╿${tz} *${prefix}indo19* 
┃✜╿${tz} *${prefix}indo20* 
┃✜╿${tz} *${prefix}indo21* 
┃✜╿${tz} *${prefix}indo22* 
┃✜╿${tz} *${prefix}indo23* 
┃✜╿${tz} *${prefix}indo24* 
┃✜╿${tz} *${prefix}indo25* 
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.internalmenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭═══❲ *INTERNALMENU* ❳══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}readmore*
┃✜╿${tz} *${prefix}chatlist*
┃✜╿${tz} *${prefix}addsticker*
┃✜╿${tz} *${prefix}addvn*
┃✜╿${tz} *${prefix}getvn*
┃✜╿${tz} *${prefix}getsticker*
┃✜╿${tz} *${prefix}liststicker*
┃✜╿${tz} *${prefix}listvn*
┃✜╿${tz} *${prefix}addimage*
┃✜╿${tz} *${prefix}getimage*
┃✜╿${tz} *${prefix}imagelist*
┃✜╿${tz} *${prefix}addvideo*
┃✜╿${tz} *${prefix}getvideo*
┃✜╿${tz} *${prefix}listvideo*   
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.cekmenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *CEKMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}gantengcek*
┃✜╿${tz} *${prefix}cantikcek*
┃✜╿${tz} *${prefix}jelekcek*
┃✜╿${tz} *${prefix}goblokcek*
┃✜╿${tz} *${prefix}begocek*
┃✜╿${tz} *${prefix}pintercek*
┃✜╿${tz} *${prefix}jagocek*
┃✜╿${tz} *${prefix}nolepcek*
┃✜╿${tz} *${prefix}babicek*
┃✜╿${tz} *${prefix}bebancek*
┃✜╿${tz} *${prefix}baikcek*
┃✜╿${tz} *${prefix}jahatcek*
┃✜╿${tz} *${prefix}anjingcek*
┃✜╿${tz} *${prefix}haramcek*
┃✜╿${tz} *${prefix}kontolcek*
┃✜╿${tz} *${prefix}pakboycek*
┃✜╿${tz} *${prefix}pakgirlcek*
┃✜╿${tz} *${prefix}sangecek*
┃✜╿${tz} *${prefix}bapercek*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.tagmenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *TAGMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}ganteng*
┃✜╿${tz} *${prefix}cantik*
┃✜╿${tz} *${prefix}jelek*
┃✜╿${tz} *${prefix}goblok*
┃✜╿${tz} *${prefix}bego*
┃✜╿${tz} *${prefix}pinter*
┃✜╿${tz} *${prefix}jago*
┃✜╿${tz} *${prefix}babi*
┃✜╿${tz} *${prefix}beban*
┃✜╿${tz} *${prefix}baik*
┃✜╿${tz} *${prefix}jahat*
┃✜╿${tz} *${prefix}anjing*
┃✜╿${tz} *${prefix}monyet*
┃✜╿${tz} *${prefix}haram*
┃✜╿${tz} *${prefix}kontol*
┃✜╿${tz} *${prefix}pakboy*
┃✜╿${tz} *${prefix}pakgirl*
┃✜╿${tz} *${prefix}sadboy*
┃✜╿${tz} *${prefix}sadgirl*
┃✜╿${tz} *${prefix}wibu*
┃✜╿${tz} *${prefix}nolep*
┃✜╿${tz} *${prefix}hebat*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.gamemenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *GAMEMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}slot*
┃✜╿${tz} *${prefix}simi*
┃✜╿${tz} *${prefix}jumlah*
┃✜╿${tz} *${prefix}hurufkebalik*
┃✜╿${tz} *${prefix}tebakgambar*
┃✜╿${tz} *${prefix}nickff*
┃✜╿${tz} *${prefix}kapankah*
┃✜╿${tz} *${prefix}apakah*
┃✜╿${tz} *${prefix}ramalnomer* 
┃✜╿${tz} *${prefix}ramalcinta* 
┃✜╿${tz} *${prefix}jodohbali* 
┃✜╿${tz} *${prefix}ramalnikah* 
┃✜╿${tz} *${prefix}taksirmimpi* 
┃✜╿${tz} *${prefix}suit*                   
┃✜╿${tz} *${prefix}boomtext*
┃✜╿${tz} *${prefix}holoh*
┃✜╿${tz} *${prefix}heleh*
┃✜╿${tz} *${prefix}huluh*
┃✜╿${tz} *${prefix}hilih*
┃✜╿${tz} *${prefix}halah* 
┃✜╿${tz} *${prefix}kapital*
┃✜╿${tz} *${prefix}textfont*
┃✜╿${tz} *${prefix}citacita*
┃✜╿${tz} *${prefix}laut*
┃✜╿${tz} *${prefix}darat*
┃✜╿${tz} *${prefix}udara*
┃✜╿${tz} *${prefix}tebak*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.randomtext = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *RANDOMTEXT* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}quotes2*
┃✜╿${tz} *${prefix}quotes1*
┃✜╿${tz} *${prefix}kusonime*
┃✜╿${tz} *${prefix}renungan*
┃✜╿${tz} *${prefix}samehadaku*
┃✜╿${tz} *${prefix}infonomer*
┃✜╿${tz} *${prefix}jadwaltv*
┃✜╿${tz} *${prefix}tvjadwal*
┃✜╿${tz} *${prefix}fml*
┃✜╿${tz} *${prefix}cinta*
┃✜╿${tz} *${prefix}resepmasakan*
┃✜╿${tz} *${prefix}cersex*
┃✜╿${tz} *${prefix}cerpen*
┃✜╿${tz} *${prefix}jadwalsholat*
┃✜╿${tz} *${prefix}pantun*
┃✜╿${tz} *${prefix}cuaca*
┃✜╿${tz} *${prefix}namaninja*
┃✜╿${tz} *${prefix}fake*
┃✜╿${tz} *${prefix}spamcall*
┃✜╿${tz} *${prefix}spamemail*
┃✜╿${tz} *${prefix}fakta*
┃✜╿${tz} *${prefix}gcard*
┃✜╿${tz} *${prefix}quotes*
┃✜╿${tz} *${prefix}quotesnime*
┃✜╿${tz} *${prefix}kbbilazimedia*
┃✜╿${tz} *${prefix}covid*
┃✜╿${tz} *${prefix}wikiid*
┃✜╿${tz} *${prefix}wikien*
┃✜╿${tz} *${prefix}covidid*
┃✜╿${tz} *${prefix}kbbi*
┃✜╿${tz} *${prefix}infogempa*
┃✜╿${tz} *${prefix}randomquran*
┃✜╿${tz} *${prefix}kisanabi*
┃✜╿${tz} *${prefix}artinama*
┃✜╿${tz} *${prefix}artimimpi*
┃✜╿${tz} *${prefix}artijadian*
┃✜╿${tz} *${prefix}chord*
┃✜╿${tz} *${prefix}lirik*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.fastmenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *FASTMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────── 
┃✜╿${tz} *${prefix}fb*
┃✜╿${tz} *${prefix}steam*
┃✜╿${tz} *${prefix}stalktwit*
┃✜╿${tz} *${prefix}stalkgithub*
┃✜╿${tz} *${prefix}bc*
┃✜╿${tz} *${prefix}clearall*
┃✜╿${tz} *${prefix}ssweb*
┃✜╿${tz} *${prefix}randomhusbu*
┃✜╿${tz} *${prefix}pinterest*
┃✜╿${tz} *${prefix}randomwaifu*
┃✜╿${tz} *${prefix}randomwaifu1*
┃✜╿${tz} *${prefix}stalkig*
┃✜╿${tz} *${prefix}estetikpic*
┃✜╿${tz} *${prefix}memeindo*
┃✜╿${tz} *${prefix}darkjokes*
┃✜╿${tz} *${prefix}urlshort*
┃✜╿${tz} *${prefix}shortener*
┃✜╿${tz} *${prefix}fox*
┃✜╿${tz} *${prefix}dog*
┃✜╿${tz} *${prefix}cat*
┃✜╿${tz} *${prefix}panda*
┃✜╿${tz} *${prefix}panda1*
┃✜╿${tz} *${prefix}bird*
┃✜╿${tz} *${prefix}koala*
┃✜╿${tz} *${prefix}meme*  
┃✜╿${tz} *${prefix}asupan*
┃✜╿${tz} *${prefix}asupan1*
┃✜╿${tz} *${prefix}asupan2*
┃✜╿${tz} *${prefix}ngakak*
┃✜╿${tz} *${prefix}pin* 
┃✜╿${tz} *${prefix}foto* 
┃✜╿${tz} *${prefix}bts*
┃✜╿${tz} *${prefix}exo*
┃✜╿${tz} *${prefix}blackpink*
┃✜╿${tz} *${prefix}attp*
┃✜╿${tz} *${prefix}katailham*
┃✜╿${tz} *${prefix}manga1*
┃✜╿${tz} *${prefix}character*
┃✜╿${tz} *${prefix}ttp4*
┃✜╿${tz} *${prefix}ttp3*
┃✜╿${tz} *${prefix}ttp2*
┃✜╿${tz} *${prefix}ttp1*
┃✜╿${tz} *${prefix}sticker*
┃✜╿${tz} *${prefix}stickergif*
┃✜╿${tz} *${prefix}bug*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.sertifikat = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *SERTIFIKAT* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *PERATURAN* ❳═══⊷
┃⚀ *JGN SPAM FITUR BOT*
┃⚁ *JGN CALL BOT INI*
┃⚂ *JGN TOXIC KE BOT*
┃⚃ *JGN PLAGIAT BOT*
┃⚄ *JGN CULIK BOT INI*
┃⚅ *JGN MEMBANDING BOT*
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────────
┃✜╿${tz} *${prefix}fftourserti* 
┃✜╿${tz} *${prefix}fftourserti2*
┃✜╿${tz} *${prefix}fftourserti3*
┃✜╿${tz} *${prefix}fftourserti4*
┃✜╿${tz} *${prefix}fftourserti5*
┃✜╿${tz} *${prefix}pubgtourserti*
┃✜╿${tz} *${prefix}pubgtourserti2*
┃✜╿${tz} *${prefix}pubgtourserti3*
┃✜╿${tz} *${prefix}pubgtourserti4*
┃✜╿${tz} *${prefix}pubgtourserti5*
┃✜╿${tz} *${prefix}mltourserti*
┃✜╿${tz} *${prefix}mltourserti2*
┃✜╿${tz} *${prefix}mltourserti3*
┃✜╿${tz} *${prefix}mltourserti4*
┃✜╿${tz} *${prefix}mltourserti5*
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.ownermenu = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *OWNERMENU* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *DARE OWNE* ❳═══⊷
┃⚀ *TIDAK TAU CARA PAKE*
┃⚁ *FITUR OWNER?? SILAHKAN*
┃⚂ *HUBUNGI OUTHER BOT*
┃⚃ *KETIK ${prefix}outher* 
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────────
┃✜╿${tz} *${prefix}dellprem* 
┃✜╿${tz} *${prefix}addprem*
┃✜╿${tz} *${prefix}clearall*
┃✜╿${tz} *${prefix}bc*
┃✜╿${tz} *${prefix}setout*
┃✜╿${tz} *${prefix}setwelcome*
┃✜╿${tz} *${prefix}settz*
┃✜╿${tz} *${prefix}setthum*
┃✜╿${tz} *${prefix}setpp*
┃✜╿${tz} *${prefix}setprefix*
┃✜╿${tz} *${prefix}setreply* 
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.makerfoto = (prefix, bulan, tchat, ownername, tz, namebot, author, apikey) => { 
    return`╭════❲ *MAKERFOTO* ❳═══⊷ 
┃✜╭───────────────── 
┃✜╿ *BOT WHATSAPP NEW*
┃✜╿ *OWNER : ${ownername}*
┃✜╿ *AUTHOR : ${author}*
┃✜╿ *NAMEBOT : ${namebot}*
┃✜╿ *BULAN : ${bulan}*
┃✜╿ *CHAT : ${tchat}*
┃✜╰─────────────────
╰══════════════════⊷
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭═════❲ *DARE OWNE* ❳═══⊷
┃⚀ *TIDAK TAU CARA PAKE*
┃⚁ *FITUR OWNER?? SILAHKAN*
┃⚂ *HUBUNGI OUTHER BOT*
┃⚃ *KETIK ${prefix}outher* 
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
╭══════❲ *MENU.1* ❳══════⊷ 
┃✜╭───────────────────
┃✜╿${tz} *${prefix}crossgun* 
┃✜╿${tz} *${prefix}bakar*
┃✜╿${tz} *${prefix}pensil*
┃✜╿${tz} *${prefix}pantaimalam*
┃✜╿${tz} *${prefix}costumwp*
┃✜╿${tz} *${prefix}facebookpage*
┃✜╿${tz} *${prefix}gtav*
┃✜╿${tz} *${prefix}deteksiumur*
┃✜╿${tz} *${prefix}removebg*
┃✜╿${tz} *${prefix}deteksiwajah*
┃✜╿${tz} *${prefix}wanted* 
┃✜╰─────────────────
╰═══════════════════⊷ 
 ▻►▻►▻►▻►▻►▻►▻►▻►▻►▻
${apikey}`
}
exports.prem1 = (command) => { 
    return`MAAF TAPI FITUR *${command}* KHUSUS MEMBER PREMIUM. INGIN DAFTAR PREMIUM?? SILAHKAN HUBUNGI OWNER`
    }